// Workaround to include D3D10.h with VS2003
#ifndef __out
#define __out
#endif
#ifndef __in
#define __in
#endif
#ifndef __inout
#define __inout
#endif
#ifndef __in_opt
#define __in_opt
#endif
#ifndef __out_opt
#define __out_opt
#endif
#ifndef __inout_opt
#define __inout_opt
#endif
#ifndef __in_ecount
#define __in_ecount(x)
#endif
#ifndef __in_ecount_opt
#define __in_ecount_opt(x)
#endif
#ifndef __out_ecount
#define __out_ecount(x)
#endif
#ifndef __out_ecount_opt
#define __out_ecount_opt(x)
#endif
#ifndef __inout_ecount
#define __inout_ecount(x)
#endif
#ifndef __inout_ecount_opt
#define __inout_ecount_opt(x)
#endif
#ifndef __in_bcount_opt
#define __in_bcount_opt(x)
#endif
#ifndef __out_bcount_opt
#define __out_bcount_opt(x)
#endif
#ifndef __inout_bcount_opt
#define __inout_bcount_opt(x)
#endif
